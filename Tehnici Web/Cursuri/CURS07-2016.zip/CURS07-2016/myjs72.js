
 
window.onload = myMain;

function myMain() {
 document.getElementById("quiz").onsubmit = totalQuiz;} 



function totalQuiz() { 
var fe = document.getElementById("quiz").elements; 
var q1 = fe[0].elements; 
var q2 = fe[4].elements; 
var x=0;
for (var i = 0; i<q1.length; i++) if (q1[i].checked) x = x + parseInt(q1[i].value); 
for (var i = 0; i<q2.length; i++) if (q2[i].checked) x = x + parseInt(q2[i].value); 
alert(x);
}

