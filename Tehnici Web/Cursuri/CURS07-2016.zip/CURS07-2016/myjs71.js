 
window.onload = myMain;

function myMain() {
document.getElementById("citire").onsubmit
 = suma;
}



function suma() {
var x = document.getElementById("nr").value;
var s = 0; 
for (var i=1; i<= parseInt(x) ; i++) s=s+i;
alert('Suma este ' +  s); 
}



