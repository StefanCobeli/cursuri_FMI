
 $(document).ready(function(){
 var art = $("article");
  $("#b1").click(function(){
    $("p",art).hide();
  });
alert( $("p",art)[0].innerHTML);
alert( $("p",art).eq(1).html());
$("p",art).eq(2).remove();
$("#nou").append("<p> Paragraf nou </p>");
/* var p = $("<p> Paragraf nou </p>");
p.appendTo("#nou"); */

}); 
								 