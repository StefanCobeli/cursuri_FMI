
 $(document).ready(function(){
   $("#b1").click(function(){
    $("span.show").css("background-color", "yellow").show("slow");
  });
  
  $("#b2").click(function(){
    $("p").slideUp("slow");
  });
  
  $("#b3").click(function(){
    $("p").slideDown("fast");
  });
  
  $("#b4").click(function(){
    $("img").fadeToggle("slow");
  });

$( "p" ).each(function( index, elem) {
 $( elem).prepend( '<b> P' + index + ': </b>' );
});
}); 
								 