
 
 
		
		
$(document).ready(function(){
  
  $("a").attr("target","_blank");

$("#play").click(function(event){
	
		$("#box").animate({opacity: "0.1", left: "+=400"}, 1200)
		.animate({opacity: "0.4", top: "+=160", height: "20", width: "20"}, "slow")
		.animate({opacity: "1", left: "0", height: "100", width: "100"}, "slow")
		.animate({top: "0"}, "fast")
		.slideUp()
		.slideDown("slow", function() {alert("Gata")});
		//event.preventDefault();
	return false;
	});

})
