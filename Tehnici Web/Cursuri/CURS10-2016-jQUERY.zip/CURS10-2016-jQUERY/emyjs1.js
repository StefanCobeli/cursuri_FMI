
 $(document).ready(function(){
  $("#b1").click(function(){
    $("article p").hide();
  }).dblclick(function(){
    $("article p").show().css("color","red");
  });
  $("article p").click(function(){$(this).css("background-color","gray");});
  $("p.spec").hover(function(){$(this).css("background-color","red");});
  $("#slide").hover (function(){ $(this).css("color", "red").slideToggle();});
  
  }); 
								 