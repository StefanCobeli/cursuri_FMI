
 $(document).ready(function(){
  
  
$( "#tabs" ).tabs();
		
$( "#datepicker" ).datepicker({onSelect: function (data, dp){ $("#tab h2").text("Ai selectat data: " + data)}});

$("#b").click(function () {alert("hi"); 

$.ajax({
  type: "GET",  
  url:  "toload.html", 
  success: function(data) {
                                                    alert("hi again");
                                                  },
  error: function (){alert("eroare");}                                                
                                                  
});
 });  
		            
})


/*

$("#aj").click(function () {$("#tabs-4").load("toload.html #doi", function(responseText, statusText,xhr) {
               
                                                  if(statusText == "error")
                                                 {alert("Eroare")} else {alert(responseText);}
                                                });
		        }); 

$("#b").click(function () {alert("hi"); $.get("toload.html", function(data) {
                                                    alert(data);
                                                  });
                                                });                
                
                */