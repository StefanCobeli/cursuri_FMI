
 
 
		
		
$(document).ready(function(){
  
  
$("#b1").click(function(event){
	
		$("#box1").animate({opacity: "0.1", left: "+=400"}, 1200)
		.animate({opacity: "0.4", top: "+=160", height: "20", width: "20"}, "slow")
		.animate({opacity: "1", left: "0", height: "100", width: "100"}, "slow")
		.animate({top: "0"}, "fast")
		.slideUp()
		.slideDown("slow");
		event.preventDefault();
	return false;
	});

    
    $("#b2").click(function(event){
	
		$("#box2").animate({opacity: "0.1", left: "+=400"}, 1200)
		.animate({opacity: "0.4", top: "+=160", height: "20", width: "20"}, "slow")
		.animate({opacity: "1", left: "0", height: "100", width: "100"}, "slow")
		.animate({top: "0"}, "fast")
		.slideUp()
		.slideDown("slow");
		event.preventDefault();
	return false;
	});
    var ok = true;
    function foreverap(i){$("#rez").append("<span> span" + i+ "  </span>"); 
	                      if (ok == true) {setTimeout(foreverap(i),2000);};}
    
        
    $("#b4").click( function () {ok = false;});
    
     $("#b3").click( function () {foreverap (1);});

    
})
