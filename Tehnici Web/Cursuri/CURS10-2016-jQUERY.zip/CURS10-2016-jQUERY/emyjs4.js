
 
 
 $(document).ready(function(){
   $("div.cap").click(function(){
    $("p.show").toggle("slow");
  });
        
anim();

  
}); 


		
	

function anim(){$("#doi").fadeIn(2000,  function()
        {
                $("#doi").fadeOut(2000, anim);
        });}