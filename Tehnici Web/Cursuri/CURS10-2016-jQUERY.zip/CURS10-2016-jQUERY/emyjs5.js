
 
 
		
		
$(document).ready(function(){
  
  
/* $(window).keydown(function(event){
                      alert(event.keyCode);
}); */

$(window).on("keydown", function(event){alert(event.keyCode)});

$("#unu").on("mouseover", function(){$(this).text("APASATI ORICE TASTA")}); 
$("#unu").on("mouseover", function(){$(this).css("color", "red")}); 

})
