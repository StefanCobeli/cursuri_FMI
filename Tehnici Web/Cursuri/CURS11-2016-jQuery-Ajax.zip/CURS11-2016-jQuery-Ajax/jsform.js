/*window.onload=function () { alert("hello");} */
   $(document).ready(function(){
 
   $("#testform").submit(function (event){
   
  event.preventDefault();
 
  var dataform = $("#testform").serialize(); alert(dataform);
  

/*			   $.post("myphpform.php", dataform,
            function(data)
        {
             alert("serialize():" + dataform);
			 $("#info").html(data);
        }); */
		

$.ajax({
  type: "POST",
  url:"myphpform.php",
  data: dataform,
  success: function (data, textStatus){ alert("serialize():" + dataform);
			  $("#info").html(data);},
  error:  function (data, statusCode){alert("Eroare: " + statusCode);}
  }); 	
 })
	
}) 

