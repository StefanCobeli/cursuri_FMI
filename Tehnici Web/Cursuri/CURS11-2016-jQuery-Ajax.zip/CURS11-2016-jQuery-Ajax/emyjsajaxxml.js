
 $(document).ready(function(){
 

//************** get **********************
$("#myget").click(function () { 

$.ajax({
type: "GET",
url: "date.xml",
dataType:'xml',
/*success: function (data){
       persoane = data;
	   for (var i=0;  i< persoane.length; i++)
	   $("#rez").append ("<p>" + persoane[i].pers.nume +" are varsta " +persoane[i].pers.varsta +"</p>"); 
   
         }, */
success : callback,         
error:function (){alert("error");}
}) ;

}) 


function callback(data){
       $(data).find('pers').each(function(){
     var nume = $(this).attr('nume');
     var varsta = $(this).attr('varsta');     
   $("#rez").append ("<p>" + nume +" are varsta " +varsta +"</p>"); 
      
       })
	   
         }
})
