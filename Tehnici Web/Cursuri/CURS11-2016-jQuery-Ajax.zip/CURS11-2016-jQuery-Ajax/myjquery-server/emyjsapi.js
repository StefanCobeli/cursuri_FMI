
 $(document).ready(function(){
 
$("#tabs").tabs();
		
$("#myload").click(function () {$("#tabs-1").load("toload.html #doi", function(data, statusCode) {
               
                                                  if(statusCode == "error")
                                                 {alert("Eroare")}; alert(data);
                                                });
		        });
//************** get **********************

$("#myget").click(function () {
  /* $.get("ex.txt", function (data, statusCode){alert("hi"+data); $("#tabs-2").html(data);
   });
  }); */


   $.ajax({
   type: "GET",
   url:"ex.txt",
   dataType: "text",
   success: function (data, statusCode){$("#tabs-2").html(data);},
   error:  function (data, statusCode){alert("Eroare:" + statusCode);}
  }); 
 })  
 

 // ***************** post ****************
$("#mypost").click(function(){ 		
var nume =  $("#nume").text();
var varsta = $("#varsta").text();
		
/*$.post("myphp.php",
        {
                "name": nume,
                "age": varsta
        },
        function(data, textStatus)
        {
                alert("Server (php): " + data);
        }); 
		
*/
		
	
$.ajax({
  type: "POST",
  url:"myphp.php",
  data:{"name": nume,
        "age": varsta},
  success: function (data, statusCode){alert("Server (php):" + data);},
  error:  function (data, statusCode){alert("Eroare:" + statusCode);}
  }); 
  })
  
  
 //*************** xml ****************
 
 $("#myxml").click(function(){
 
 $("#tabs-4").empty();
 $("#tabs-4").append("<h3> Date citite din fisier xml:</h3>");
 
 var $persoane; // obiect jQuery 
$.ajax({       // ajax cu jQuery
type:"GET",
url: "date.xml",
success: function (data){
       $persoane = $("pers", data);
	   for (var i=0; i<$persoane.length; i++)
	   $("#tabs-4").append ("<p>" + $persoane.eq(i).attr("nume") +" are varsta " +$persoane.eq(i).attr("varsta")+"</p>");
   
         },
		  error:  function (data, statusCode){alert("Eroare:" + statusCode);}
}) 


 /* 
var client = new XMLHttpRequest(); // ajax cu XMLHttpRequest
client.open("GET", "date.xml");
client.send();

client.onreadystatechange = function () {
  var persoane = this.responseXML.getElementsByTagName("pers"); 
   alert(persoane.length);
   alert( "responseXML: " + this.responseXML);   
   alert( "responseText: " + this.responseText);
 };
 */

})




//*********** json *****************

$("#myjson").click(function(){
var persoane; // obiect json
$("#tabs-5").empty();
$("#tabs-5").append("<h3> Date citite din fisier json:</h3>");
/* $.getJSON("date.json", function (data){
       persoane = data; 
	   // alert(persoane.length);
	   for (var i=0;  i< persoane.length; i++)
	   $("#tabs-5").append ("<p>" + persoane[i].pers.nume +" are varsta " +persoane[i].pers.varsta +"</p>"); 
   
         } ); */

$.ajax({
type: "GET",
url: "date.json",
dataType: "json",
success: function (data){
       persoane = data; 
	   // alert(persoane.length);
	   for (var i=0;  i< persoane.length; i++)
	   $("#tabs-5").append ("<p>" + persoane[i].pers.nume +" are varsta " +persoane[i].pers.varsta +"</p>"); 
   
         },
		  error:  function (data, statusCode){alert("Eroare:" + statusCode);}
}) 
})

			
})
