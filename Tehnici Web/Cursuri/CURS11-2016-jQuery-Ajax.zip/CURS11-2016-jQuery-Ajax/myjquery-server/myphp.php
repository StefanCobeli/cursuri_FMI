<?php
	echo $_POST['name']."  are "
	. $_POST['age']." ani ";
?>

