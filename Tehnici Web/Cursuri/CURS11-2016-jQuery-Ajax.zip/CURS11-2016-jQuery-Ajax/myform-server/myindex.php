<?php
	echo "<h1> Ce mai faci acum?</h1>";
?>

