<?php
   $name = $_POST['name'];
   $age = $_POST['age'];
   $city = $_POST['city'];
   echo $name." din ".$city." are ".$age." ani."; 

?>

