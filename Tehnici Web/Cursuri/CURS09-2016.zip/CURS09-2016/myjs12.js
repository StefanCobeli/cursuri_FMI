
 window.onload = myMain;

									  
function myMain(){ alert(document.cookie +"\n scrise de ex-location-history-cookie"); creste(); scrie();}
function creste(){
    var x = Number(localStorage.getItem('hits'));
    if (x){
       localStorage.setItem('hits', x +1);
    }else{
       localStorage.setItem('hits', 1);
    }}
	
	function scrie(){
	document.getElementById("scrie").value = localStorage.getItem('hits');
	}
	
	
									 