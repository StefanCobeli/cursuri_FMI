
 
window.onload = modifica;
 

 
 
 function deschide(){ 
 
 opener.document.getElementById("parinte").value= document.getElementById("copil").value; }



 function modifica(){
	 
	 document.getElementById("trimiteparinte").onclick = deschide;
  
 }

									  
								 