
 
window.onload = myMain;


 

function myMain() {

 window.addEventListener('keydown', function (event) {  document.getElementById('key').value = event.key;
                                                       document.getElementById('mkey').value = event.shiftKey;
                                      document.getElementById('which').value = event.which;
									  document.getElementById('code').value = event.keyCode;
									  
									  });

}


									  
								 