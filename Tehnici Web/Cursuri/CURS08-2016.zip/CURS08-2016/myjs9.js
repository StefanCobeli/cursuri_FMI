
 
window.onload = myMain;


 /*
function myMain() {

document.onmousemove = function (e) { document.getElementById('cx').value = e.clientX;
                                      document.getElementById('cy').value = e.clientY;}
}



function myMain() {

document.addEventListener("mousemove", function (event) { document.getElementById('cx').value = event.clientX;
                                      document.getElementById('cy').value = event.clientY;}, false);

}*/


function myMain() {

window.addEventListener('mousemove', pozMouse, false);

}

function pozMouse(event) {  document.getElementById('cx').value = event.clientX;
                                      document.getElementById('cy').value = event.clientY;}
									  
								 